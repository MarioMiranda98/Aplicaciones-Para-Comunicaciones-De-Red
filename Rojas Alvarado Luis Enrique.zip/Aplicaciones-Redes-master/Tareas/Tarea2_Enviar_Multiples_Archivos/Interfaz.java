import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.Socket;
import java.io.*;
import java.util.*;

public class Interfaz extends JFrame {
    private static final long serialVersionUID = 1L;
    public Interfaz() {
        setBounds(450, 150, 500, 300);
        setTitle("Envio de archivos");
        setResizable(false);

        panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout());
        panelSuperior = new JPanel();
        panelInferior = new JPanel();
        elegirArchivo = new JButton("Elegir archivo");
        enviarArchivo = new JButton("Enviar");
        enviarArchivo.setEnabled(false);
        enviarCarpeta = new JButton("Enviar Carpeta");
        //enviarCarpeta.setEnabled(false);
        conectar = new JButton("Conectar");
        estado = new JLabel("Estado: Desconectado");
        porcentajeE = new JLabel("Porcentaje: ");
        texto = new JTextArea(50, 100);
        texto.setEditable(false);
        texto.append("Archivo:\t\tTama\u00F1o:");
        misArchivos = new ArrayList<>();


        conectar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    cl = new Socket(HOST, PUERTO);
                    estado.setText("Estado: Conectado");
                    enviarArchivo.setEnabled(true);
                } catch(Exception e1) {
                    estado.setText("Estado: Desconectado"); 
                    e1.printStackTrace(); 
                }
            }
        });

        elegirArchivo.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0) {
                eleccionArchivo();
            }
        });

        enviarArchivo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                File fichero=new File("");
                try{
                    enviarArchivos(fichero,"");    
                }catch (Exception e3){
                    e3.printStackTrace();
                }
                
            }
        });

        enviarCarpeta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                directory = new JFileChooser();
                directory.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                directory.requestFocus();
                int r = directory.showOpenDialog(Interfaz.this);
                if (r == JFileChooser.APPROVE_OPTION) {
                    try{
                        enviarCarpetas(directory.getSelectedFile(), "" + directory.getCurrentDirectory());
                    }catch(Exception e2){
                        e2.printStackTrace();
                    }
                    
                }
            }
        });

        panelSuperior.setLayout(new BorderLayout());
        panelSuperior.add(estado, BorderLayout.NORTH);
        panelSuperior.add(porcentajeE, BorderLayout.CENTER);
        panelInferior.add(elegirArchivo);
        panelInferior.add(enviarArchivo);
        panelInferior.add(enviarCarpeta);
        panelInferior.add(conectar);
        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
        panelPrincipal.add(texto, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);
        add(panelPrincipal);


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    
    public void eleccionArchivo() {
        file = new JFileChooser();
        file.requestFocus();
        int r = file.showOpenDialog(Interfaz.this);
        if(r == JFileChooser.APPROVE_OPTION) {
            File f = file.getSelectedFile();
            misArchivos.add(new Archivo(f.getName(), f.length(), f.getAbsolutePath()));
            texto.append("\n" + f.getName() + "\t\t" + f.length());
        }
    }

   public void enviarArchivos(File file, String destino) throws IOException {
        enviarArchivo.setEnabled(false);
        Socket cl = new Socket(HOST, PUERTO);
        String nombre = file.getName();
        long tam = file.length();
        long enviados = 0;
        int porcentaje;
        int n;
        String ruta = file.getAbsolutePath();

        System.out.println("Conexion establecida");
        DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
        DataInputStream dis = new DataInputStream(new FileInputStream(ruta));

        // Usamos destino para ir almacenando la ruta del archivo/carpeta
        dos.writeUTF(destino);
        dos.flush();
        // Despues mandamos el nombre del archivo
        dos.writeUTF(nombre);
        dos.flush();
        // Y finalmente su tamaño
        dos.writeLong(tam);
        dos.flush();

        System.out.format("Enviando el archivo: %s...\n", nombre);
        System.out.format("Que esta en la ruta: %s\n", ruta);

        while (enviados < tam) {
            byte[] b = new byte[1500];
            n = dis.read(b);
            dos.write(b, 0, n);
            dos.flush();
            enviados = enviados + n;
            porcentaje = (int) (enviados * 100 / tam);
            System.out.println("\rSe ha transmitido el: " + porcentaje + "% ...");
        }

        System.out.println("Archivo enviado");
        dos.close();
        dis.close();
        cl.close();
    }

    // el parametro destino nos permite guardar la ubicacion del archivo
    public void enviarCarpetas(File carpeta, String destino) throws IOException {
        System.out.format("Carpeta %s con los archivos:\n", carpeta.getName());

        if (destino.equals("")) destino = carpeta.getName(); // evita que se cree en c:\\
        else destino = destino + "\\" + carpeta.getName(); // concatenar la ruta de los archivos
        for (File file : carpeta.listFiles()) {
            if (file.isDirectory()) enviarCarpetas(file, destino);
            else enviarArchivos(file, destino);
        }
    }

    public static void main(String[] args) {
        new Interfaz();
    }

    private JPanel panelPrincipal;
    private JPanel panelSuperior;
    private JPanel panelInferior;
    private JButton elegirArchivo, enviarArchivo;
    private JButton enviarCarpeta;
    private JButton conectar;
    private JLabel estado, porcentajeE;
    private JTextArea texto;
    final int PUERTO = 9000;
    final String HOST = "127.0.0.1";
    private Socket cl;
    private JFileChooser file;
    private JFileChooser directory;
    private ArrayList <Archivo> misArchivos;
    private DataOutputStream dos;
    private DataInputStream dis;
}
#ifndef __MERGESORT__
#define __MERGESORT__

#include<stdio.h>
#include<stdlib.h>

void mezclaMerge(int* numeros, int bajo, int mitad, int alto);
void ordenamientoMerge(int* numeros, int bajo, int alto);

#endif // !__MERGESORT__
#! /bin/bash
#compilar interfaz
javac interfaz/*.java

#compilar logica
javac logica/*.java

#compilar busqueda
javac logica/busqueda/*.java

#compilar transferencia
javac logica/transferencia/*.java

#compilar principal
javac *.java



